package dev.rapidtech.flutter_animated_text

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
